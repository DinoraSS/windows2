SELECT
    p.prod_subcategory,
    EXTRACT(YEAR FROM p.purchase_date) AS year,
    SUM(p.amount) AS total_sales
FROM
    purchases p
WHERE
    EXTRACT(YEAR FROM p.purchase_date) BETWEEN 1998 AND 2001
GROUP BY
    p.prod_subcategory,
    year
ORDER BY
    p.prod_subcategory,
    year;
WITH subcategory_sales AS (
    SELECT
        p.prod_subcategory,
        EXTRACT(YEAR FROM p.purchase_date) AS year,
        SUM(p.amount) AS total_sales
    FROM
        purchases p
    WHERE
        EXTRACT(YEAR FROM p.purchase_date) BETWEEN 1998 AND 2001
    GROUP BY
        p.prod_subcategory,
        year
)
SELECT
    curr.prod_subcategory,
    curr.year,
    curr.total_sales AS current_year_sales,
    prev.total_sales AS previous_year_sales
FROM
    subcategory_sales curr
    LEFT JOIN subcategory_sales prev ON curr.prod_subcategory = prev.prod_subcategory
        AND curr.year = prev.year + 1
ORDER BY
    curr.prod_subcategory,
    curr.year;
WITH subcategory_sales AS (
    SELECT
        p.prod_subcategory,
        EXTRACT(YEAR FROM p.purchase_date) AS year,
        SUM(p.amount) AS total_sales
    FROM
        purchases p
    WHERE
        EXTRACT(YEAR FROM p.purchase_date) BETWEEN 1998 AND 2001
    GROUP BY
        p.prod_subcategory,
        year
),
sales_comparison AS (
    SELECT
        curr.prod_subcategory,
        curr.year,
        curr.total_sales AS current_year_sales,
        prev.total_sales AS previous_year_sales
    FROM
        subcategory_sales curr
        LEFT JOIN subcategory_sales prev ON curr.prod_subcategory = prev.prod_subcategory
            AND curr.year = prev.year + 1
)
SELECT DISTINCT
    s1.prod_subcategory
FROM
    sales_comparison s1
WHERE
    s1.current_year_sales > s1.previous_year_sales
    AND NOT EXISTS (
        SELECT 1
        FROM sales_comparison s2
        WHERE
            s2.prod_subcategory = s1.prod_subcategory
            AND (s2.current_year_sales <= s2.previous_year_sales OR s2.previous_year_sales IS NULL)
    )
ORDER BY
    s1.prod_subcategory;